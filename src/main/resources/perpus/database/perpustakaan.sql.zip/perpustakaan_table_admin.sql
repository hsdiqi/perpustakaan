
CREATE TABLE `admin` (
  `username` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `password` varchar(15) NOT NULL,
  `id_admin` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin` (`username`, `nama`, `password`, `id_admin`) VALUES
('admin', 'Admin', 'admin123', 1),
('operator', 'Operator', 'operator123', 2);

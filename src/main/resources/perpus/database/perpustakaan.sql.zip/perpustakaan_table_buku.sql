
CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `kode_buku` varchar(5) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `tahun_rilis` int(4) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `buku` (`id_buku`, `kode_buku`, `genre`, `judul`, `tahun_rilis`, `stok`) VALUES
(1, '1702', 'Sosial', 'Krisis Kebebasan', 2001, 2),
(2, '1101', 'Filsafat', 'Dunia Shopie', 1991, 2),
(3, '1102', 'Filsafat', 'Dunia Anna', 2014, 2),
(4, '1103', 'Filsafat', 'How To Die', 2020, 2),
(5, '1201', 'Biography', 'Karl Marx', 2002, 2),
(6, '1202', 'Biography', 'H.O.S Tjokroaminoto', 2015, 2),
(7, '1401', 'Horor', 'KKN di Desa Penari', 2019, 2),
(8, '1701', 'Sosial', 'Kelahiran yang dipersoalkan', 1990, 2),
(9, '1801', 'Fiksi Sejarah', 'Bumi Manusia', 1980, 2),
(10, '1601', 'Agama', 'Menuju Hidup Mulia', 1998, 2),
(11, '1901', 'Novel', 'Logika Cinta', 2016, 2),
(12, '1902', 'Novel', 'drama Mangir', 2000, 2),
(13, '1104', 'Filsafat', 'Filsafat ketuhanan', 1984, 2),
(14, '1602', 'Agama', 'Islam sebagai Hukum ', 2004, 2),
(15, '1105', 'Filsafat', 'Madilog Tan Malaka', 2019, 2),
(16, '1402', 'Horor', 'Sewu Dino', 2019, 2),
(17, '1301', 'Hukum', 'Hukum Adat Indonesia', 2020, 2);
